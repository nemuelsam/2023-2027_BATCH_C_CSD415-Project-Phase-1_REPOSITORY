# AI-Powered Multimodal Misinformation Detection and Verification System

LaTeX Beamer presentation using the supplied KTU-style sidebar template.

## Compile
Run twice to resolve sidebar and outline navigation:
```bash
pdflatex main.tex && pdflatex main.tex
```
Or use `latexmk -pdf main.tex`.

## Structure
- `main.tex`: section includes
- `preamble.tex`: title, authors, packages and metadata
- `theme/ktutheme.sty`: supplied KTU-style theme
- `sections/`: individual slide sections
- `assets/College_logo.png`: logo displayed by the theme
- `assets/system_architecture_reference.jpg`: supplied system architecture image

Implementation status is labelled in the slides: video, OCR for scanned PDFs, SHAP, PostgreSQL and external fact verification are planned extensions.
