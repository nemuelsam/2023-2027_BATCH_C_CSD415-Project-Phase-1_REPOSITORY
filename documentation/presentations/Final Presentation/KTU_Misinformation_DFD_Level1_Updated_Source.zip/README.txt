KTU Multimodal Misinformation Detection Presentation — Overleaf source

Files:
- main.tex: Beamer presentation source (includes DFD Level 0 and newly added DFD Level 1)
- theme/ktutheme.sty: KTU presentation theme
- assets/ktu_logo.png: KTU logo
- assets/system_architecture_reference.jpg: supplied system architecture image

To use:
1. Upload this ZIP to Overleaf as a new project.
2. Open main.tex as the main document.
3. Select pdfLaTeX as the compiler.
4. Compile.

Note: The DFD Level 1 shows current text/PDF/image processing and trained model use. The results database, video/OCR and external fact-checking are marked as planned/not yet implemented.
